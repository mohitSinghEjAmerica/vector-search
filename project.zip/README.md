# Workshop Demo Application - Let AI Be Your Docs

This is a demo application for the [Let AI Be Your Docs](https://github.com/mongodb-developer/vector-search-workshop) workshop.
